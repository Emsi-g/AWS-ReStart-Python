import os
import subprocess

subprocess.run(["ls","-l","README.md"])

command = "uname"
commandArgument = "-a"
print(f'The system information with command: {command} {commandArgument}')
subprocess.run([command, commandArgument])

subprocess.run(["df", "-h"])

command = "ps"
commandArgument = "-x"
print(f'Gathering active process information with command: {command} {commandArgument}')
subprocess.run([command, commandArgument])